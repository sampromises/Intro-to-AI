I discussed the writing portion of the assignment with a couple of classmates: Kayla Oliva and Max Summermatter. But I came up with all answers on my own and can explain the reasoning behind each answer myself.

I worked on the coding portion alone.
There is a high level description of my algorithm is in the header comment for my magic.py file.
I got a bunch of help from TA Kevin Yang. He helped me understand the idea of keeping a list of variables and updating the domain at every placement/removal of a grid value.

Thanks, Kevin!
